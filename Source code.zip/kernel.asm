bits 16
org 0x0000

start:
    mov ax, cs
    mov ds, ax

    mov ax, 0013h
    int 10h

    mov byte [desk_sel], 0
    mov byte [fe_sel], 0

    call desktop

main:
    xor ah, ah
    int 16h

    cmp ah, 4Bh
    je left_key
    cmp ah, 4Dh
    je right_key
    cmp ah, 48h
    je up_key
    cmp ah, 50h
    je down_key
    cmp ah, 1Ch
    je enter_key

    cmp al, 'k'
    je open_kie
    cmp al, 'K'
    je open_kie

    cmp al, 'f'
    je open_fe
    cmp al, 'F'
    je open_fe

    cmp al, 27
    je close_window

    jmp main

left_key:
    cmp byte [mode], 0
    jne main
    mov byte [desk_sel], 0
    call desktop
    jmp main

right_key:
    cmp byte [mode], 0
    jne main
    mov byte [desk_sel], 1
    call desktop
    jmp main

up_key:
    cmp byte [mode], 2
    jne main
    cmp byte [fe_sel], 0
    je main
    dec byte [fe_sel]
    call desktop
    call fe_window
    jmp main

down_key:
    cmp byte [mode], 2
    jne main
    cmp byte [fe_sel], 4
    je main
    inc byte [fe_sel]
    call desktop
    call fe_window
    jmp main

enter_key:
    cmp byte [mode], 0
    jne main

    cmp byte [desk_sel], 0
    je open_kie
    jmp open_fe

open_kie:
    mov byte [mode], 1
    call desktop
    call kie_window
    jmp main

open_fe:
    mov byte [mode], 2
    call desktop
    call fe_window
    jmp main

close_window:
    mov byte [mode], 0
    call desktop
    jmp main

desktop:
    mov ax, 0A000h
    mov es, ax

    xor di, di
    mov cx, 64000
    mov al, 11
    rep stosb

    mov bx, 145
    mov cx, 35
grass:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    mov di, ax
    mov cx, 320
    mov al, 2
    rep stosb
    inc bx
    pop cx
    loop grass

    mov bx, 180
    mov cx, 20
bar:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    mov di, ax
    mov cx, 320
    mov al, 1
    rep stosb
    inc bx
    pop cx
    loop bar

    call draw_kie_icon
    call draw_fe_icon

    mov si, top_hint
    mov dh, 1
    mov dl, 11
    call pr

    mov si, esc_hint
    mov dh, 23
    mov dl, 24
    call pr

    mov si, starttxt
    mov dh, 23
    mov dl, 1
    call pr

    ret

draw_kie_icon:
    mov bx, 50
    mov cx, 18
kie_icon_y:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    add ax, 30
    mov di, ax
    mov cx, 22
    mov al, 15
    rep stosb
    inc bx
    pop cx
    loop kie_icon_y

    mov si, kietxt
    mov dh, 9
    mov dl, 4
    call pr

    cmp byte [desk_sel], 0
    je .selected
    mov si, kietxt
    jmp .print
.selected:
    mov si, kietxt_sel
.print:
    mov dh, 21
    mov dl, 3
    call pr
    ret

draw_fe_icon:
    mov bx, 50
    mov cx, 18
fe_icon_y:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    add ax, 100
    mov di, ax
    mov cx, 22
    mov al, 14
    rep stosb
    inc bx
    pop cx
    loop fe_icon_y

    mov si, fetxt
    mov dh, 9
    mov dl, 13
    call pr

    cmp byte [desk_sel], 1
    je .selected
    mov si, fetxt
    jmp .print
.selected:
    mov si, fetxt_sel
.print:
    mov dh, 21
    mov dl, 12
    call pr
    ret

kie_window:
    call draw_window

    mov si, kie_title
    mov dh, 5
    mov dl, 6
    call pr

    mov si, closex
    mov dh, 5
    mov dl, 32
    call pr

    mov si, kie_page
    mov dh, 8
    mov dl, 10
    call pr
    ret

fe_window:
    call draw_window

    mov si, fe_title
    mov dh, 5
    mov dl, 6
    call pr

    mov si, closex
    mov dh, 5
    mov dl, 32
    call pr

    mov si, fe_header
    mov dh, 8
    mov dl, 8
    call pr

    call fe_files
    ret

fe_files:
    mov dh, 10
    mov dl, 8
    mov si, file1
    mov bl, 0
    call fe_line

    mov dh, 11
    mov dl, 8
    mov si, file2
    mov bl, 1
    call fe_line

    mov dh, 12
    mov dl, 8
    mov si, file3
    mov bl, 2
    call fe_line

    mov dh, 13
    mov dl, 8
    mov si, file4
    mov bl, 3
    call fe_line

    mov dh, 14
    mov dl, 8
    mov si, file5
    mov bl, 4
    call fe_line
    ret

fe_line:
    push si
    cmp [fe_sel], bl
    jne .not_sel

    mov si, arrow
    call pr
    jmp .after_arrow

.not_sel:
    mov si, space
    call pr

.after_arrow:
    pop si
    inc dl
    call pr
    ret

draw_window:
    mov ax, 0A000h
    mov es, ax

    mov bx, 38
    mov cx, 115
shadow_y:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    add ax, 42
    mov di, ax
    mov cx, 238
    mov al, 8
    rep stosb
    inc bx
    pop cx
    loop shadow_y

    mov bx, 35
    mov cx, 115
win_y:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    add ax, 35
    mov di, ax
    mov cx, 238
    mov al, 7
    rep stosb
    inc bx
    pop cx
    loop win_y

    mov bx, 35
    mov cx, 12
title_y:
    push cx
    mov ax, bx
    mov dx, 320
    mul dx
    add ax, 35
    mov di, ax
    mov cx, 238
    mov al, 1
    rep stosb
    inc bx
    pop cx
    loop title_y
    ret

pr:
    mov [leftcol], dl
    mov ah, 02h
    xor bh, bh
    int 10h

nextc:
    lodsb
    or al, al
    jz done

    cmp al, 13
    je cr
    cmp al, 10
    je nl

    mov ah, 0Eh
    xor bh, bh
    mov bl, 15
    int 10h
    jmp nextc

cr:
    mov ah, 03h
    xor bh, bh
    int 10h
    mov dl, [leftcol]
    mov ah, 02h
    int 10h
    jmp nextc

nl:
    mov ah, 03h
    xor bh, bh
    int 10h
    inc dh
    mov dl, [leftcol]
    mov ah, 02h
    int 10h
    jmp nextc

done:
    ret

leftcol db 0
mode db 0
desk_sel db 0
fe_sel db 0

starttxt db "[Start]",0
top_hint db "Arrows + Enter   K = KIE   F = FE",0
esc_hint db "ESC = Close",0

kietxt db "KIE",0
fetxt db "FE",0
kietxt_sel db "[KIE]",0
fetxt_sel db "[FE]",0

kie_title db "Kailan Internet Explorer",0
fe_title db "File Explorer",0
closex db "X",0

kie_page db "Welcome to info.kai!",13,10
         db "This is KailanOS XP.",13,10
         db "Local web pages soon.",0

fe_header db "A:\",13,10
          db "Use UP/DOWN to select",0

arrow db ">",0
space db " ",0

file1 db "KTOSKRNL.KEX",0
file2 db "SYSTEM32",0
file3 db "MEDIA",0
file4 db "STARTUP.WAV",0
file5 db "README.TXT",0
