bits 16
org 0x7C00

KERNEL_SEG equ 0x1000
KERNEL_SECTORS equ 32

start:
    cli
    xor ax, ax
    mov ds, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov ax, KERNEL_SEG
    mov es, ax
    xor bx, bx

    mov ah, 02h
    mov al, KERNEL_SECTORS
    mov ch, 0
    mov cl, 2
    mov dh, 0
    mov dl, 0
    int 13h

    jc disk_error

    jmp KERNEL_SEG:0000

disk_error:
    mov si, err
.print:
    lodsb
    or al, al
    jz $
    mov ah, 0Eh
    int 10h
    jmp .print

err db "Disk error loading ktoskrnl.kex",0

times 510-($-$$) db 0
dw 0xAA55
